// module.exports = {

//   'githubAuth' : {
//     'clientID'      : 'secretClientId',
//     'clientSecret'  : 'clientSecret',
//     'callbackURL'   : 'callbackURL'
//   }

// };

module.exports = {

  'githubAuth' : {
    'clientID'      : '2b4f2248c195586d3214',
    'clientSecret'  : '8b3360750bd666cfed22f6c43bad5e7424222acf',
    'callbackURL'   : 'http://127.0.0.1:3000/auth/github/callback'
  },
  'idolAuth' : {
    'apiKey' : '53b0f751-6ddb-4aba-b169-a3971bbcffe1'
  }
  
};