module.exports = {
  URI: 'mongodb://azai91:$hackreactor&@ds027758.mongolab.com:27758/Stackd_MongoDB'
}